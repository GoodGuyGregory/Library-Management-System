package sangu;

public class Settings {
	final static String schemata = "information_schema.schemata.tbl";
	final static String tables = "information_schema.table.tbl";
	final static String columns = "information_schema.columns.tbl";
	static int no_Of_schemaTable_records = 1;
	static int no_Of_Table_records = 3;
	static String currentSchema = "information_schema";
}
