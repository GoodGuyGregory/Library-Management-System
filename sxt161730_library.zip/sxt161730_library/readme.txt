				
							LIBRARY MANAGEMENT SYSTEM 

Introduction :

		The Library Management System is evolved around the need of the librarian. It 
helps the librarian system users to interact with the database through a GUI. This system 
allows the librarian to add a borrower, checkout/checkin books, view books, view fines 
etc. The Librarian enters the required details manually to perform certain actions. This 
system automates the basic operations such as calculating fines etc. and also provides 
logon facility to the Librarian. 

Requirements :

		This project requires Eclipse software which is a Java-based open source platform 
that allows to create a customized development environment(IDE). This project also 
requires MySQL database. 

Installation :

1. Download Eclipse Mars 2.0 from eclipse.org consortium.
2. Download all project source files including build files.
3. Install my MySQL database and store the required tables.
4. Open Eclipse and create a new project and import .java files into the source directory.
5. Configure and build path to include rs2xml.jar and mysql-connector-java-5.1.40-bin.jar.
6. Compile and run the project by clicking a play button located on the toolbar. 

Conclusion :

		The Library Management system is ready to use and the user may not face any 
difficulties if he/she goes through the installation process correctly.




		


